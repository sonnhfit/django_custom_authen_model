from django.shortcuts import render



from django.http import HttpResponse
# Create your views here.
#MVT model view template , mvc


def index(request):
    return HttpResponse('xin chao')